package org.mdhtmdmi.example;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;

import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.mdht.uml.cda.ClinicalDocument;
import org.eclipse.mdht.uml.cda.Section;
import org.eclipse.mdht.uml.cda.util.CDAUtil;
import org.eclipse.mdht.uml.cda.util.ValidationResult;
import org.mdmi.core.Mdmi;
import org.mdmi.core.runtime.RuntimeService;
import org.mdmi.core.util.FileUtil;
import org.openhealthtools.mdht.uml.cda.consol.ConsolPackage;
import org.openhealthtools.mdht.uml.cda.consol.ResultsSection;
import org.openhealthtools.mdht.uml.cda.consol.ResultsSection2;

public class Run {

	public static void main(String[] args) throws FileNotFoundException, Exception {
	
		
		try {
			
			
		// Initialize MDHT Consol Library  - Sometimes can take a bit
		ConsolPackage.eINSTANCE.eClass();
		
		org.mdmi.Node asdf;
		

//		HapiContext asdf;
		
		
		// Load two cda documents
		ClinicalDocument cd1 = CDAUtil.load(new FileInputStream("samples/DischargeSummary_2014Edition_sample.xml"));
		ClinicalDocument cd2 = CDAUtil.load(new FileInputStream("samples/DischargeSummary_sample.xml"));
		
		
		// Initial merge code - just add the sections
		for (Section s : cd2.getSections()) {		
				cd1.addSection(EcoreUtil.copy(s));
		}
		

		
		org.slf4j.LoggerFactory ddd;
		
		
	
		// 	Start of MDMI - Properties are used to customize aspects of maps - not needed yet
			HashMap<String, String> sourceProperties = new HashMap<String, String>();
			HashMap<String, String> targetProperties = new HashMap<String, String>();

			// Load the source maps
			File sourceFile = new File("maps/ContinuityOfCareDocument.mdmi");
			InputStream sourceStream = new FileInputStream(sourceFile);
			Mdmi.INSTANCE.getResolver().resolve(sourceStream);

			// Load the target map
			File targetFile = new File("maps/fhirBundle.mdmi");
			InputStream targetStream = new FileInputStream(targetFile);
			Mdmi.INSTANCE.getResolver().resolve(targetStream);

			// Save merge document to byte array for MDMI
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			CDAUtil.save(cd1,bos);
			
			// Run the transformation
			String result = RuntimeService.runTransformation(
				"CDAR2.ContinuityOfCareDocument", bos.toByteArray(), "STU3.FHIRResource", "resources/results",
				sourceProperties, targetProperties);

			System.out.println(result);

		} catch (Exception e) {
			e.printStackTrace();
		}

		
		

	}

}
